ZBrush Camera Bank recovery

Recommended: open a-recovered.zpr with File > Open, then import
CameraBank25_v3_2.zcv using Camera Bank 25 > IMPORT BANK.

Alternative: load CB620092277855G0003_shirt.ztl with Tool > Load Tool,
draw the Tool and enter Edit mode, then import the same camera bank.
Keep this ZTL basename. It preserves the first SubTool camera identifier.
The ZTL is byte-for-byte identical to the original a.ztl; only its filename differs.
A ZPR project may use an arbitrary filename, but preserve the SubTool markers.

Verified in ZBrush 2023.2.1: all five native camera recalls and their saved
canvas dimensions and SubTool visibility; public bank import; ZPR save/reopen
with all ten names preserved; public camera 01/02 recall after reopening.
Original inputs were preserved. This is a file recovery, not a plugin update.
Camera data remains in the separate .zcv file.
