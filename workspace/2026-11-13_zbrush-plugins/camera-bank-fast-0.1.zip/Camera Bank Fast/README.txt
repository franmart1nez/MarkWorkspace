CAMERA BANK FAST 0.1 - SEPARATE EXPERIMENTAL VARIANT
Windows / ZBrush 2023.2.1 target

PURPOSE
A standalone Camera Bank for models with 100-300 SubTools. It does not require
Render Capture or Generate and Export ID. The normal Camera Bank is separate.

BEHAVIOR
Keeps 25 cameras, saved transforms, canvas/lens data, effective visibility
(including folders and Solo), gray/orange flags, bank import/export and
compatible merge handling. Data remains v9 (123,088 bytes).

The first model binding reads the SubTool names. Initial registration gives
each mesh a stable CB marker. Subsequent ordinary camera saves update the
bank's visibility masks without selecting and renaming every mesh. Recall
checks native IDs by index, then changes eyes without selecting every mesh.
Routine save/recall status notices do not impose a two-second pause.

A changed Tool, count, ordered native-ID list or bank invalidates the binding
and triggers full name validation. The first save after a structural change
rebuilds identifiers once. Merges still require the same visibility in ALL
occupied cameras (including gray ones) and a retained identifier. A missing
non-equivalent visible group is rejected.

LIMITS OF THE FAST PATH
This is not a claim of zero iteration: saving visibility must read the eyes,
and recall must check IDs and apply visibility. These are indexed metadata
operations; they do not activate each SubTool.

ZBrush duplicates can share a native ID. Ambiguous duplicates require name
checks. If many duplicated IDs belong to different visibility patterns,
recall still needs to select those ambiguous pieces. Saves check duplicate-ID
members with different markers even when their previous visibility was equal.

A name-only edit to an unselected uniquely identified mesh does not invalidate
its native ID. Fast keeps its established binding until a full validation.
Use RESCAN MODEL after manually editing/removing CB identifiers and before
sending externally edited names. The normal Camera Bank validates all names
on every operation. This difference is why Fast is a separate variant.

WORKFLOW
1. Run INSTALAR FAST.cmd. In an open ZBrush: Macro > Reload All Macros, then
   Mak Plugins > Load Camera Bank Fast. Controls are under ZPlugin > Camera
   Bank Fast. The 25 slots and store/update controls work like normal Camera Bank.
2. For an existing bank, open its matching ZTL/ZPR, import the bank into Fast,
   and store/update once to establish stable per-mesh identifiers.
3. Save the matching ZTL/ZPR AFTER marker updates, then export its Fast bank.
   Send this matching pair to the recipient.
4. For routine camera changes, no separate refresh button is needed.
5. After external identifier edits, use RESCAN MODEL. Structural changes are
   detected automatically. New unmarked geometry is rejected, as in the normal
   plugin; a new bank is needed when ancestry cannot be established safely.

Use one camera writer per Tool: normal Camera Bank and Fast have independent
session banks and controls, but both use the model's CB name markers. Storing
with the other writer can replace those markers. Merely installing Fast does
not replace normal Camera Bank, Render Capture or ID.

INSTALLATION
The installer only writes CameraBankFast25, MakCameraBankFastData and its own
reload macro. It backs up replacements and never closes/restarts ZBrush.
DESINSTALAR FAST.cmd removes only Fast-owned files after verified backups.
The bundled ZFileUtils64.dll is the unchanged native Maxon dependency.

VALIDATION
See VERIFICATION.md for the actual tests, native measurements and limitations.
Editable source: CameraBankFast25.txt. Generator: Development/build_fast.py.
The generator uses the included reviewed standard_camera_baseline.txt copy.
The delivered source, binary, installer and rebuild work independently.
